import pic1 from "../assets/images/details-big.png";
import pic2 from "../assets/images/image_01.png";
import pic3 from "../assets/images/image_02.png";
import pic5 from "../assets/images/Screen Shot 2022-06-10 at 11.29.06 AM.png";
import pic6 from "../assets/images/Screen Shot 2022-06-10 at 11.31.40 AM.png";
import pic7 from "../assets/images/Screen Shot 2022-06-10 at 11.30.52 AM.png";

import pic4 from "../assets/images/product_image_01-1.png";

export const Detailsimages = [pic1, pic5, pic6, pic7];
