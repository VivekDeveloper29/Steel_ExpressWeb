import React from "react";
import Footer from "../SharedComponents/Footer";
import Navbar from "../SharedComponents/Navbar";
import About_us_page_amico from "../assets/images/About_us_page_amico.svg";
import { getWithAuthCallWithtext } from "../api/ApiServices";
import ApiConfig from "../api/ApiConfig";
import { useState } from "react";
import { useEffect } from "react";

const About = () => {
  const [terms, setTerms] = useState("");
  useEffect(() => {
    getTerms();
  }, []);


  const getTerms = () => {
    getWithAuthCallWithtext(ApiConfig.ABOUT_US)
      .then((data) => {
        setTerms(data.text);
      })
      .catch((error) => {
        console.log(error);
      });
  }
 return (
    <main>
      <Navbar />
      <div className="main-howWeWork TermsConditions-main">
        <div className="img-how-work">
          <h3 className="TermsConditions-title">About Us</h3>
          {/* {
               tearms_and_condtion && tearms_and_condtion.map((tandc) => 
               {tandc.content}
               )} */}
          <div className="TermsConditions-para">
          <p dangerouslySetInnerHTML={{ __html:terms }}></p>
            <div>

            </div>


          </div>

        </div>
      </div>
      <Footer />
    </main>
  );
};
export default About;
