import React from "react";
import notification_icon from "../assets/images/notification_icon.svg";
import Navbar from "../SharedComponents/Navbar";
import Footer from "../SharedComponents/Footer";
import ApiConfig from "../api/ApiConfig";
import { useState } from "react";
import { useEffect } from "react";
import { Link } from "react-router-dom";

const Notifications = () => {
  const [notification, setNotification] = useState(null);
  useEffect(() => {
    getNotification();
  }, []);

  let getNotification = () => {
    fetch(ApiConfig.NOTIFICATION, {
      method: "Get",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Token " + localStorage.getItem("auth_token"),
      },
    }).then((result) => {
      result.json().then((resp) => {
        console.log("notifications", resp);
        setNotification(resp.notifications);
      });
    });
  };
  console.log(notification);

  return (
    <main>
      <Navbar />
      <div className="main-notification">
        {notification &&
          notification.map((notifications) => (
            // <Link
            //   to={"/Getquote/" + notifications.order_id}
            //   className="d-block"
            // >
            <Link
              to={"/MyQutoes/"}
              className="d-block"
            >
              <div className="noti-box">
                <div className="icon-para-main">
                  <div className="icon">
                    <span>
                      <img src={notification_icon} alt="" />
                    </span>
                  </div>

                  <div className="paragraph-noti">
                    <p>{notifications.notification_body}</p>

                    <div className="time-date">
                      <label className="me-2">{notifications.created_at}</label>
                      {/* <label>04:44:48 pm</label> */}
                    </div>
                  </div>
                </div>
              </div>
            </Link>
          ))}
      </div>
      <Footer />
    </main>
  );
};

export default Notifications;
