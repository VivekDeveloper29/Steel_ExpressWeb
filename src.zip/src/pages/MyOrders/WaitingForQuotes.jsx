import React, { useState, useEffect } from "react";
import ApiConfig from "../../api/ApiConfig";
import { postWithAuthCall, simpleGetCallWithErrorResponse } from "../../api/ApiServices";
import pic3 from "../../assets/images/product_image_01-1.png";
import { Link, useNavigate } from "react-router-dom";
import jsPDF from "jspdf";
import swal from "sweetalert";
// import ApiConfig from "../api/ApiConfig";

const WaitingForQuotes = ({waiting_quits}) => {

  const [quote_status, setQuoteStatusUpdate] = useState([]);
  const navigate=useNavigate();
  
 
  const generatePDF = () => {
     
    var doc = new jsPDF("p", "pt", "a4");
    doc.html(document.querySelector(("#cont")), {
      callback: function (pdf) {
        // var pageCount=doc.internal.getNumberOfPages();
        // pdf.deletePage(pageCount);
        pdf.save("mypdf.pdf");
      }

    });
  };
 
  const QuoteStatusUpdate=(id)=>{
    console.log()
    postWithAuthCall(
      ApiConfig.QUOTSTATUS, 
      JSON.stringify({ quote_id:id,quote_status:"Quote Accepted"}) 
    ).then((res) => {
      console.log(res);
      setQuoteStatusUpdate(res);
      swal(res.message);
      // navigate("/PopularExperts/",{state:res})
      
    
    });
  }
  const QuoteStatusRejected=(id)=>{
    console.log()
    postWithAuthCall(
      ApiConfig.QUOTSTATUS, 
      JSON.stringify({ quote_id:id,quote_status:"Quote Rejected"}) 
    ).then((res) => {
      console.log(res);
      setQuoteStatusUpdate(res);
      swal(res.message);
      // navigate("/PopularExperts/",{state:res})
      
    
    });
  }
  
  

  return (
    <main className="mayOrder-status-main">
       {waiting_quits && waiting_quits.map((order_items) => (
      <div className="order-box" id="cont">
        <div className="inner-content" >
          <div className="left-content" >
            <div className="image ">
              <img src={order_items.order_image[0]} alt="" />
            </div>
            <div className="content">
              <p className="top-par">
              {order_items.order_items && order_items.order_items.length > 0 && [0].product_name}
              </p>
              <p className="number">{order_items.order_items && order_items.order_items.length > 0 && [0] .product_number}</p>
              {/* <div>
                <label className="key-name">Thickness</label>
                <label className="key-value">{order_items.order_items && order_items.order_items.length >0 && [0] .product_thickness}</label>
              </div>
              <div>
                <label className="key-name">Width</label>
                <label className="key-value">{order_items.order_items &&  order_items.order_items.length >0 && [0].product_width}</label>
              </div> */}
              <div>
                <label className="key-name">Status</label>
                <label className="status-waiting">{order_items && order_items.current_order_status}</label>
              </div>
            </div>
          </div>
          <div className="right">
            <p className="placed-date">Order placed on  {order_items.order_date}</p>
          
          <div className="onGoing_btnMain">
          {/* onClick={()=>QuoteStatusUpdate(order_items.id)} */}
            <Link to={"#"}   className="ongoing-btn">
              <button onClick={()=>QuoteStatusUpdate(order_items.id)} >Accepted</button>
            </Link>

            <Link to={"#"} className="ongoing-btn">
              <button onClick={()=>QuoteStatusRejected(order_items.id)}>Rejected</button>
            </Link>

            <Link to={"#"} onClick={generatePDF} className="ongoing-btn">
              <button>Download PDF</button>
            </Link>

            {/* <Link to={"/MyOrderDetails/" + order_items.id} className="ongoing-btn">
              <button>View Quote</button>
            </Link> */}
          </div>
          </div>
        </div>
      </div>
       ))}
    </main>
  );
};

export default WaitingForQuotes;
