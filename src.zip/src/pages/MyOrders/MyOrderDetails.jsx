import React, { useEffect, useState } from "react";
import Footer from "../../SharedComponents/Footer";
import Navebar from "../../SharedComponents/Navbar";
import pic3 from "../../assets/images/product_image_01-1.png";
import { useParams } from "react-router-dom";
import tick_completed from "../../assets/images/tick_completed.svg";
import in_progress from "../../assets/images/in_progress.svg";

import { simpleGetCall } from "../../api/ApiServices";
import ApiConfig from "../../api/ApiConfig";
import jsPDF from "jspdf";
import pdfMake from 'pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';
import htmlToPdfmake from 'html-to-pdfmake';

import { Stepper } from "react-form-stepper";
const MyOrderDetails = () => {
  const [my_order_detail, setMyOrderDetail] = useState("");
  let params = useParams();
  let id = params.id;
  console.log("id", id);
  useEffect(() => {
    getMyOrderDetail();
  }, []);

  let getMyOrderDetail = () => {
    simpleGetCall(
      ApiConfig.MYORDERDETAIL + id
    ).then((res) => {
      console.log(res);
      // if (res.result) {
      setMyOrderDetail(res.order);
    });
  };

  // Function will execute on click of button
  const onButtonClick = () => {
    // using Java Script method to get PDF file
    fetch('SamplePDF.pdf').then(response => {
      response.blob().then(blob => {
        // Creating new object of PDF file
        const fileURL = window.URL.createObjectURL(blob);
        // Setting various property values
        let alink = document.createElement('a');
        alink.href = fileURL;
        alink.download = 'SamplePDF.pdf';
        alink.click();
      })
    })


  }
  const generatePDF = () => {
     
    var doc = new jsPDF("p", "pt", "a4");
    doc.html(document.querySelector(("#cont")), {
      callback: function (pdf) {
        // var pageCount=doc.internal.getNumberOfPages();
        // pdf.deletePage(pageCount);
        pdf.save("mypdf.pdf");
      }

    });
  };

  return (
    <main >
      <Navebar />
      <div className="main-order-details"  >
        <section className="product-summery" >
          <div className="order-box">
            <div className="summery-heading-top" >
              {/* <label htmlFor="">Product Summary</label> */}
            </div>
            <div className="inner-content"  > 
              <div className="left-content ">
                <div className="image " >
                  <img
                    src={
                      my_order_detail.order_image &&
                      my_order_detail.order_image[0]
                    }
                    alt=""
                  />
                </div>
                <div className="content" id="cont"  >
                  <p className="top-par">
                    {my_order_detail &&
                      my_order_detail.order_items &&
                      my_order_detail.order_items[0].product_name}
                  </p>
                  <p className="number">
                    {my_order_detail &&
                      my_order_detail.order_items &&
                      my_order_detail.order_items[0].product_number}
                  </p>
                  <div>
                    <label className="key-name">Thickness:</label>
                    <label className="key-value">
                      {my_order_detail &&
                        my_order_detail.order_items &&
                        my_order_detail.order_items[0].product_thickness}
                    </label>
                  </div>
                  <div >
                    <label className="key-name">Width:</label>
                    <label className="key-value">
                      {my_order_detail &&
                        my_order_detail.order_items &&
                        my_order_detail.order_items[0].product_width}
                    </label>
                  </div>
                  <div >
                    <label className="key-name">Quantity:</label>
                    <label className="key-value">
                      {my_order_detail &&
                        my_order_detail.order_items &&
                        my_order_detail.order_items[0].quantity}
                    </label>
                  </div>
                  <div>
                    <label className="key-name">Grade:</label>
                    <label className="key-value">
                      {my_order_detail &&
                        my_order_detail.order_items &&
                        my_order_detail.order_items[0].product_grade}
                    </label>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section className="order-stepper" >
          <div className="order-box">
            <div className="d-flex justify-content-between">

              <div className="summery-heading-top">
                <label htmlFor="">Quote</label>
              </div>
              <div className="right">
                {/* onClick={onButtonClick} */}
                {/* onClick={this.generatePDF} */}
                <button className="status-name" id="download-button" onClick={generatePDF} type="primary">
                  Download Quote
                </button>
              </div>
            </div>

            <div className="inner-content-stepper" >

              {my_order_detail &&
                my_order_detail.order_status_summary.length &&
                my_order_detail.order_status_summary.map(
                  (order_details, index) => {
                    return (
                      <>
                        <div id="stepper">
                          <div class="d-flex justify-content-between" >
                            <div className="left d-flex ">
                              <div class="d-flex flex-column  align-items-center">
                                <div class="rounded-circle  px-3  ">
                                  <img src={tick_completed} alt height={25} width={25} />
                                </div>

                                <div class="line h-100  "></div>
                              </div>
                              <div className="stepper-content content ">
                                <p>{order_details.order_status}</p>
                                <label htmlFor="">{order_details.status_on}</label>
                              </div>
                            </div>

                            <div className="right">
                              <label className="status-name">Completed</label>
                            </div>
                          </div>
                        </div>
                      </>
                    )
                  })}






              {/* <div class="d-flex justify-content-between">
                  <div className="left d-flex ">
                    <div class="d-flex flex-column  align-items-center">
                      <div class="rounded-circle  px-3  ">
                        <img src={tick_completed} alt height={25} width={25} />
                      </div>

                      <div class="line h-100  "></div>
                    </div>
                    <div className="stepper-content content ">
                      <p>Quote sent</p>
                      <label htmlFor="">26-03-2022, 10:30 AM</label>
                    </div>
                  </div>

                  <div className="right">
                    <label className="status-name">Completed</label>
                  </div>
                </div>
                <div class="d-flex justify-content-between">
                  <div className="left d-flex ">
                    <div class="d-flex flex-column  align-items-center">
                      <div class="rounded-circle  px-3  ">
                        <img src={tick_completed} altheight={25} width={25} />
                      </div>

                      <div class="remaining-step-line h-100  "></div>
                    </div>
                    <div className="stepper-content content ">
                      <p>Quote sent</p>
                      <label htmlFor="">26-03-2022, 10:30 AM</label>
                    </div>
                  </div>

                  <div className="right">
                    <label className="status-name">Completed</label>
                  </div>
                </div>

                <div class="d-flex justify-content-between">
                  <div className="left d-flex ">
                    <div class="d-flex flex-column  align-items-center">
                      <div class="rounded-circle  px-3  ">
                        <img src={in_progress} alt height={25} width={25} />
                      </div>

                      <div class="remaining-step-line h-100  "></div>
                    </div>
                    <div className="stepper-content content ">
                      <p>Order Placed</p>
                    </div>
                  </div>

                  <div className="right">
                    <label className="status-name">In Progress</label>
                  </div>
                </div>

                <div class="d-flex ">
                  <div class="d-flex flex-column  align-items-center">
                    <div class="rounded-circle  px-3  ">
                      <div className="remaining-step"></div>
                    </div>
                  </div>
                  <div className="stepper-content content">
                    <p>Out for delivery</p>
                  </div>
                </div> */}
              {/* </div> */}

            </div>
          </div>
        </section>
      </div>
      <Footer />
    </main>
  );
};

export default MyOrderDetails;
