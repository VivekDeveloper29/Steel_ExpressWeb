import React from "react";
import { useEffect } from "react";
import { useState } from "react";
import ApiConfig from "../api/ApiConfig";
import { getWithAuthCall, getWithAuthCallWithtext } from "../api/ApiServices";
import Footer from "../SharedComponents/Footer";
import Navbar from "../SharedComponents/Navbar";



const TermsConditions = () => {
  const [terms, setTerms] = useState("");
  useEffect(() => {
    getTerms();
  }, []);


  const getTerms = () => {
    getWithAuthCallWithtext(ApiConfig.TERMS_CONDITION)
      .then((data) => {
        setTerms(data.text);
      })
      .catch((error) => {
        console.log(error);
      });
  }

  return (
    <main>
      <Navbar />
      <div className="main-howWeWork TermsConditions-main">
        <div className="img-how-work">
          <h3 className="TermsConditions-title">Terms & Conditions</h3>
          {/* {
               tearms_and_condtion && tearms_and_condtion.map((tandc) => 
               {tandc.content}
               )} */}
          <div className="TermsConditions-para">
          <p dangerouslySetInnerHTML={{ __html:terms }}></p>
            <div>

            </div>


          </div>

        </div>
      </div>
      <Footer />
    </main>
  );
};

export default TermsConditions;
