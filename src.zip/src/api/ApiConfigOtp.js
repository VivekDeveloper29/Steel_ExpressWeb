const BASE_URL = "http://steel.redbytes.in/";
const ApiConfigOtp = {
  BASE_URL:BASE_URL,
  BASE_URL_FOR_IMAGES:"http://steel.redbytes.in/",
  
  REGISTRATION:BASE_URL+"/api/register/"
 
};
export default ApiConfigOtp;
