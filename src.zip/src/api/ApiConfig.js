const BASE_URL = "http://steel.redbytes.in/api/";
const ApiConfig = {
  // BASE_URL:BASE_URL,
  // BASE_URL_FOR_IMAGES:"http://steel.redbytes.in",
  
  REGISTER:BASE_URL+"register/",
  LOGIN:BASE_URL+"login/",
  FORGAT_PASSWORD: BASE_URL + "forgot_password/",
  CATEGORY_LIST: BASE_URL + "categories/",
  UPDATE_PROFILE: BASE_URL + "edit_profile/",
  SUB_CATAGORY_ONE:BASE_URL+"sub_categories_one/",
  SUB_CATAGORY_TWO:BASE_URL+"sub_categories_two/",
  PRODUCT:BASE_URL+ "products",
  CONTACTUS:BASE_URL+ "contact_us",
  TERMS_CONDITION:BASE_URL+ "terms_and_conditions",
  PRIVACY_POLICY:BASE_URL+"privacy_policy",
  ABOUT_US:BASE_URL+"about_us",
  PRODUCT_SEARCH : BASE_URL + "product_search/",
  PRODUCT_DETAILS : BASE_URL + "product_details/?id=",
  OFFERS : BASE_URL + "offers/",
  WISHLIST : BASE_URL + "wishlist/",
  NOTIFICATION : BASE_URL + "notifications/",
  CARTDISPLAY : BASE_URL + "cart/",
  MYORDER:BASE_URL + "orders/",
  GETQUOTE:BASE_URL+"get_quote",
  FILTERORDER:BASE_URL+"filter_orders",
  MYORDERDETAIL:BASE_URL+"order_details?id=",
  FetchAdditionalDetails:BASE_URL+"fetch_additional_details",
  QUOTSTATUS:BASE_URL+"quote_update"
 

};
export default ApiConfig;